<?php 
    // Si le damos click a insertar que nos mande a la otra página
    echo "<form action='usuario_nuevo.php' method='post'>";
    echo "<p><button type='submit' name='btnNuevoUsuario'>Insertar nuevo usuario</button></p>";
    echo "</form>";
?>